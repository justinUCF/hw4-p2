/* $Id: lexer_utilities.c,v 1.3 2024/11/13 14:08:23 leavens Exp $ */
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include "lexer_utilities.h"

/* yyerror() is defined in spl_lexer.c (which is made from spl_lexer.l) */
/* formatted_yyerror() is defined in utilities.c */
